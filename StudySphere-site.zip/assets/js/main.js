/* StudySphere — shared script: header, menu, footer, popups सर्व pages वर आपोआप येतात.
   कोणत्याही page मध्ये फक्त <main> ठेवा आणि शेवटी हा script जोडा. */
(function(){
var ROOT=document.currentScript.src.replace(/assets\/js\/main\.js.*$/,'');
var UPI_ID="vikram.joshi9089@oksbi",PAYEE="StudySphere",amount=0;
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(e){}}
var dark=ls('theme')==='dark';if(dark)document.body.setAttribute('data-theme','dark');
var $=function(id){return document.getElementById(id)};
var head='<header class="no-print"><a class="logo-container" href="'+ROOT+'index.html"><span class="logo">StudySphere</span><span class="logo-sub">MPSC Group C</span></a><div class="header-controls">'
+'<button class="btn btn-telegram desktop-only" onclick="openTelegram()"><i class="fab fa-telegram-plane"></i> Telegram</button>'
+'<button class="btn btn-donate desktop-only" onclick="openDonate()"><i class="fas fa-hand-holding-heart"></i> Donate Us</button>'
+'<button class="icon-btn" onclick="toggleTheme()" id="themeBtn" aria-label="Toggle Theme"><i class="fas fa-moon"></i></button>'
+'<button class="icon-btn" onclick="toggleMenu()" aria-label="Menu"><i class="fas fa-bars"></i></button></div></header>'
+'<div class="menu-overlay no-print" id="menuOverlay" onclick="toggleMenu()"></div>'
+'<nav class="mobile-menu no-print" id="mobileMenu"><div class="menu-header"><span style="font-weight:600;color:var(--primary-color)">Menu</span><button class="icon-btn" onclick="toggleMenu()"><i class="fas fa-times"></i></button></div><div class="menu-links">'
+'<a href="'+ROOT+'index.html"><i class="fas fa-home fa-fw"></i> Home</a>'
+'<a href="'+ROOT+'prelims/index.html"><i class="fas fa-layer-group fa-fw"></i> Prelims</a>'
+'<a href="'+ROOT+'mains/index.html"><i class="fas fa-file-signature fa-fw"></i> Mains</a>'
+'<a href="'+ROOT+'current-affairs/index.html"><i class="fas fa-newspaper fa-fw"></i> चालू घडामोडी</a>'
+'<a href="'+ROOT+'guidance/index.html"><i class="fas fa-compass fa-fw"></i> Guidance</a>'
+'<a href="'+ROOT+'index.html#about"><i class="fas fa-info-circle fa-fw"></i> About</a>'
+'<a href="'+ROOT+'index.html#contact"><i class="fas fa-envelope fa-fw"></i> Contact</a>'
+'<div style="height:1px;background:var(--border-color);margin:10px 20px"></div>'
+'<button onclick="openTelegram();toggleMenu();" style="color:var(--telegram-color)"><i class="fab fa-telegram-plane fa-fw"></i> Join Telegram</button>'
+'<button onclick="openDonate();toggleMenu();" style="color:var(--donate-color)"><i class="fas fa-hand-holding-heart fa-fw"></i> Donate Us</button></div></nav>';
var foot='<footer class="no-print"><div class="footer-grid">'
+'<div class="footer-col"><h4>StudySphere</h4><p>MPSC Group C Prelims &amp; Mains साठी Study Platform.</p></div>'
+'<div class="footer-col"><h4>Quick Links</h4><ul><li><a href="'+ROOT+'index.html">Home</a></li><li><a href="'+ROOT+'index.html#about">About</a></li><li><a href="'+ROOT+'index.html#contact">Contact</a></li></ul></div>'
+'<div class="footer-col"><h4>Information</h4><ul><li><a href="'+ROOT+'privacy.html">Privacy Policy</a></li><li><a href="'+ROOT+'terms.html">Terms of Service</a></li><li><a href="'+ROOT+'sitemap.html">Sitemap</a></li></ul></div>'
+'<div class="footer-col"><h4>Support</h4><div style="display:flex;flex-direction:column;gap:10px"><button class="btn btn-telegram" onclick="openTelegram()" style="width:100%;justify-content:center"><i class="fab fa-telegram-plane"></i> Telegram</button><button class="btn btn-donate" onclick="openDonate()" style="width:100%;justify-content:center"><i class="fas fa-hand-holding-heart"></i> Donate Us</button></div></div></div>'
+'<div class="footer-bottom"><p>&copy; 2026 StudySphere. All Rights Reserved. | MPSC Group C</p></div></footer>'
+'<div class="modal-overlay no-print" id="mobileDonateModal"><div class="modal"><button class="close-modal" onclick="closeModals()">&times;</button><h2 style="font-size:1.3rem;margin-bottom:5px">StudySphere ला Support करा</h2><p style="font-size:.95rem;font-weight:500">तुमचा छोटा support platform चालू ठेवण्यास मदत करतो.</p><p style="font-size:.8rem;opacity:.7;margin-bottom:15px">Your support helps us maintain and improve StudySphere.</p>'
+'<div class="preset-amounts"><button class="amt-btn" onclick="selectPresetAmount(50,this)">₹50</button><button class="amt-btn" onclick="selectPresetAmount(100,this)">₹100</button><button class="amt-btn" onclick="selectPresetAmount(200,this)">₹200</button></div>'
+'<div class="custom-amt-group"><label style="display:block;font-size:.85rem;margin-bottom:5px">Custom Amount</label><div style="position:relative"><span class="currency-symbol">₹</span><input type="number" id="customAmt" placeholder="Enter amount" min="1" step="any" oninput="handleCustomAmount()"></div><div class="error-msg" id="amtError"></div></div>'
+'<button class="btn-pay" id="payNowBtn" onclick="initiateUPIPayment()" disabled>Pay Now</button></div></div>'
+'<div class="modal-overlay no-print" id="desktopDonateModal"><div class="modal"><button class="close-modal" onclick="closeModals()">&times;</button><h2 style="font-size:1.3rem;margin-bottom:5px">StudySphere ला Support करा</h2><p style="font-size:.95rem;font-weight:500">QR code scan करून payment करा.</p><p style="font-size:.8rem;opacity:.7;margin-bottom:15px">On desktop, scan the QR code with any UPI app.</p>'
+'<div style="margin:15px auto;width:180px;height:180px;border:1px dashed var(--border-color);display:flex;justify-content:center;align-items:center;background:#fff;border-radius:8px"><img src="'+ROOT+'assets/images/donation-qr.png" alt="Donation QR Code" style="max-width:100%" onerror="this.outerHTML=\'<div style=&quot;color:#aaa;text-align:center&quot;>DEMO QR<br>(donation-qr.png ठेवा)</div>\'"></div></div></div>'
+'<div class="modal-overlay no-print" id="comingSoonModal"><div class="modal"><i class="fas fa-tools" style="font-size:2.5rem;color:var(--primary-color);margin-bottom:15px"></i><h2 style="margin-bottom:5px">Coming Soon</h2><p style="margin-bottom:20px">हा section सध्या development मध्ये आहे.<br>कृपया पुन्हा भेट द्या.</p><button class="btn btn-primary" style="width:100%;justify-content:center;padding:10px" onclick="closeModals()">Close</button></div></div>';
var main=document.querySelector('main');
if(main){main.insertAdjacentHTML('beforebegin',head);main.insertAdjacentHTML('afterend',foot)}else{document.body.insertAdjacentHTML('afterbegin',head);document.body.insertAdjacentHTML('beforeend',foot)}
function setIcon(){$('themeBtn').innerHTML=document.body.getAttribute('data-theme')==='dark'?'<i class="fas fa-sun"></i>':'<i class="fas fa-moon"></i>'}setIcon();
window.toggleTheme=function(){var b=document.body;if(b.getAttribute('data-theme')==='dark'){b.removeAttribute('data-theme');ls('theme','light')}else{b.setAttribute('data-theme','dark');ls('theme','dark')}setIcon()};
window.toggleMenu=function(){$('mobileMenu').classList.toggle('active');$('menuOverlay').classList.toggle('active')};
window.openTelegram=function(){window.open('https://t.me/MPSCstudysphere','_blank')};
window.showComingSoon=function(){$('comingSoonModal').style.display='flex'};
window.closeModals=function(){['mobileDonateModal','desktopDonateModal','comingSoonModal'].forEach(function(i){$(i).style.display='none'})};
window.addEventListener('click',function(e){if(e.target.classList&&e.target.classList.contains('modal-overlay'))closeModals()});
window.openDonate=function(){if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){$('mobileDonateModal').style.display='flex';amount=0;$('customAmt').value='';$('payNowBtn').disabled=true;$('payNowBtn').innerText='Pay Now';$('amtError').style.display='none';document.querySelectorAll('.amt-btn').forEach(function(b){b.classList.remove('selected')})}else $('desktopDonateModal').style.display='flex'};
function validate(){var p=$('payNowBtn'),er=$('amtError'),v=$('customAmt').value;if(isNaN(amount)||amount<1){p.disabled=true;p.innerText='Pay Now';if(v!==''){er.innerText='Invalid amount. Minimum is ₹1.';er.style.display='block'}else er.style.display='none'}else{var s=String(amount);if(s.indexOf('.')>-1&&s.split('.')[1].length>2){p.disabled=true;er.innerText='Maximum 2 decimal places allowed.';er.style.display='block'}else{p.disabled=false;er.style.display='none';p.innerText='Pay ₹'+amount}}}
window.selectPresetAmount=function(a,el){amount=a;$('customAmt').value='';document.querySelectorAll('.amt-btn').forEach(function(b){b.classList.remove('selected')});if(el)el.classList.add('selected');validate()};
window.handleCustomAmount=function(){document.querySelectorAll('.amt-btn').forEach(function(b){b.classList.remove('selected')});amount=parseFloat($('customAmt').value);validate()};
window.initiateUPIPayment=function(){if(amount>=1){window.location.href='upi://pay?pa='+UPI_ID+'&pn='+PAYEE+'&am='+amount+'&cu=INR';setTimeout(closeModals,500)}};
})();
