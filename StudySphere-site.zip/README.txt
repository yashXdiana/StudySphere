StudySphere — GitHub Pages साठी फाईल्स

1) या zip मधील सर्व files/folders GitHub repository च्या root मध्ये upload करा (Add file > Upload files).
2) Settings > Pages > Branch: main, Folder: / (root) > Save.
3) donation-qr.png तुमचा QR image assets/images/ मध्ये ठेवा.

नवीन महिना जोडण्यासाठी:
- current-affairs/2026/ मध्ये नवीन folder (उदा. february/) बनवा आणि त्यात index.html ठेवा.
- gen.py ची गरज नाही: current-affairs/2026/index.html मध्ये त्या महिन्याच्या card मधून
  <a class="card soon" onclick="showComingSoon()"> ऐवजी <a class="card" href="february/index.html"> लिहा.

Header/Footer/Menu/Donate बदलायचे असेल तर फक्त assets/js/main.js बदला. Design बदलायचे असेल तर assets/css/style.css.
